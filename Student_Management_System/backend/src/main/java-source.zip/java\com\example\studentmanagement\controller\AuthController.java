package com.example.studentmanagement.controller;

import com.example.studentmanagement.model.User;
import com.example.studentmanagement.service.AuthService;
import com.example.studentmanagement.config.JwtUtil;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    private final AuthService authService;
    private final JwtUtil jwtUtil;

    public AuthController(AuthService authService, JwtUtil jwtUtil) {
        this.authService = authService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody AuthRequest request) {
        try {
            User user = authService.register(
                request.email,
                request.password,
                "STUDENT",
                request.studentId
            );

            return ResponseEntity.ok(
                new AuthResponse(
                    user.getId(),
                    user.getEmail(),
                    user.getRole(),
                    null
                )
            );

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest request) {
        try {
            User user = authService.login(
                request.email,
                request.password
            );

            String token = jwtUtil.generateToken(
                user.getEmail(),
                user.getRole()
            );

            return ResponseEntity.ok(
                new AuthResponse(
                    user.getId(),
                    user.getEmail(),
                    user.getRole(),
                    token
                )
            );

        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(401).body(e.getMessage());
        }
    }

    public static class AuthRequest {
        public String email;
        public String password;
        public Long studentId;
    }

    public static class AuthResponse {
        public Long id;
        public String email;
        public String role;
        public String token;

        public AuthResponse(
            Long id, String email, String role, String token
        ) {
            this.id = id;
            this.email = email;
            this.role = role;
            this.token = token;
        }
    }
}